import './App.css';
import { Dashboard } from './components/ui/Dashboard';


export function App(): JSX.Element {
  return (
    <div className="App">

      <Dashboard/>

    </div>
  );
}