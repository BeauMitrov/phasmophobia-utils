export interface Item {
    name: string;
    type: 'main' | 'optional' | 'light';
    image: string;
    min: number;
    max: number;
    linked?: string[];
}
  

export const itemData: Item[] = [

    // Main Items
    {
        name: "Video Camera",
        type: "main",
        image: "assets/images/main/VideoCamera.png",
        min: 1,
        max: 3,
        linked: ["Tripod"]
    },
    {
        name: "D.O.T.S. Projector",
        type: "main",
        image: "assets/images/main/DOTSProjector.png",
        min: 1,
        max: 3,
    },
    {
        name: "EMF Reader",
        type: "main",
        image: "assets/images/main/EMFReader.png",
        min: 1,
        max: 3,
    },
    {
        name: "Ghost Writing Book",
        type: "main",
        image: "assets/images/main/GhostWritingBook.png",
        min: 1,
        max: 3,
    },
    {
        name: "Spirit Box",
        type: "main",
        image: "assets/images/main/Spiritbox.png",
        min: 1,
        max: 3,
    },
    {
        name: "UV Flashlight",
        type: "main",
        image: "assets/images/main/UVFlashlight.png",
        min: 1,
        max: 3,
    },

    // Optional Items
    {
        name: "Photo Camera",
        type: "optional",
        image: "assets/images/optional/PhotoCamera.png",
        min: 1,
        max: 3,
    },
    {
        name: "Crucifix",
        type: "optional",
        image: "assets/images/optional/Crucifix.png",
        min: 1,
        max: 3,
    },
    {
        name: "Glowstick",
        type: "optional",
        image: "assets/images/optional/Glowstick.png",
        min: 1,
        max: 3,
    },
    {
        name: "Head Mounted Camera",
        type: "optional",
        image: "assets/images/optional//HeadMountedCamera.png",
        min: 1,
        max: 3,
    },
    {
        name: "Lighter",
        type: "optional",
        image: "assets/images/optional/Lighter.png",
        min: 1,
        max: 3,
    },
    {
        name: "Motion Sensor",
        type: "optional",
        image: "assets/images/optional/MotionSensor.png",
        min: 1,
        max: 3,
    },
    {
        name: "Parabolic Microphone",
        type: "optional",
        image: "assets/images/optional/ParabolicMicrophone.png",
        min: 1,
        max: 3,
    },
    {
        name: "Salt Shaker",
        type: "optional",
        image: "assets/images/optional/SaltShaker.png",
        min: 1,
        max: 3,
    },
    {
        name: "Sanity Pills",
        type: "optional",
        image: "assets/images/optional/SanityPills.png",
        min: 1,
        max: 3,
    },
    {
        name: "Smudge Sticks",
        type: "optional",
        image: "assets/images/optional/SmudgeSticks.png",
        min: 1,
        max: 3,
        linked: ["Lighter"]
    },
    {
        name: "Sound Sensor",
        type: "optional",
        image: "assets/images/optional/SoundSensor.png",
        min: 1,
        max: 3,
    },
    {
        name: "Thermometer",
        type: "optional",
        image: "assets/images/optional/Thermometer.png",
        min: 1,
        max: 3,
    },
    {
        name: "Tripod",
        type: "optional",
        image: "assets/images/optional/Tripod.png",
        min: 1,
        max: 3,
    },

    // Lights
    {
        name: "Strong Flashlight",
        type: "light",
        image: "assets/images/light/StrongFlashlight.png",
        min: 1,
        max: 3,
    },
    {
        name: "Flashlight",
        type: "light",
        image: "assets/images/light/Flashlight.png",
        min: 1,
        max: 3,
    },
    {
        name: "Candle",
        type: "light",
        image: "assets/images/light/Candle.png",
        min: 1,
        max: 3,
        linked: ["Lighter"]
    },
];