export const mapData = [
    '6 Tanglewood Drive',
    '42 Edgefield Road',
    '10 Ridgeview Court',
    'Grafton Farmhouse',
    '13 Willow Street',
    'Brownstone Highschool',
    'Bleasdale Farmhouse',
    'Sunny Meadows',
    'Sunny Meadows Restricted',
    'Prison',
    'Maple Lodge Campsite',
    'Camp Woodwind'
] as string[];