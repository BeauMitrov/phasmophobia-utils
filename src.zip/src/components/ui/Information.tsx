import React, { useEffect, useState } from 'react';
import { Item } from '../../data/Items';

interface InformationProps {
  items: Item[];
  selectedItems: Record<string, boolean>;
  disabledItems: Record<string, boolean>;
  onItemChange: (item: Item, isChecked: boolean) => void;
  isLinkedItemsDisabled: boolean;
  setIsLinkedItemsDisabled: (isDisabled: boolean) => void;
  updateLinkedItemsBorder: (isDisabled: boolean) => void;
}

export const Information: React.FC<InformationProps> = ({ items, selectedItems, disabledItems, onItemChange, isLinkedItemsDisabled, setIsLinkedItemsDisabled, updateLinkedItemsBorder }) => {

  const totalMain = items.filter(item => item.type === 'main' && !disabledItems[item.name]).length;
  const totalOptional = items.filter(item => item.type === 'optional' && !disabledItems[item.name]).length;
  const totalLight = items.filter(item => item.type === 'light' && !disabledItems[item.name]).length;  

  const [maxMain, setMaxMain] = useState<number>(3);
  const [maxOptional, setMaxOptional] = useState<number>(3);
  const [maxLight, setMaxLight] = useState<number>(1);

  useEffect(() => {
    if (maxMain > totalMain) setMaxMain(totalMain);
    if (maxOptional > totalOptional) setMaxOptional(totalOptional);
    if (maxLight > totalLight) setMaxLight(totalLight);
  }, [maxMain, maxOptional, maxLight, totalMain, totalOptional, totalLight]);

  const randomizeItems = () => {
    // Filter out linked items
    const isLinkedItem = (itemName: string) => items.some(item => item.linked?.includes(itemName));

    let mainItems = items.filter(item => item.type === 'main' && !disabledItems[item.name] && !(isLinkedItem(item.name) && !isLinkedItemsDisabled));
    let optionalItems = items.filter(item => item.type === 'optional' && !disabledItems[item.name] && !(isLinkedItem(item.name) && !isLinkedItemsDisabled));
    let lightItems = items.filter(item => item.type === 'light' && !disabledItems[item.name] && !(isLinkedItem(item.name) && !isLinkedItemsDisabled));
    
    const shuffleArray = (array: Item[]) => array.sort(() => Math.random() - 0.5);
    
    const selectedMainItems = shuffleArray(mainItems).slice(0, maxMain);
    const selectedOptionalItems = shuffleArray(optionalItems).slice(0, maxOptional);
    const selectedLightItems = shuffleArray(lightItems).slice(0, maxLight);
    
    // Combine all selected items
    const selectedItemsArray = [...selectedMainItems, ...selectedOptionalItems, ...selectedLightItems];
    
    items.forEach(item => {
      const isChecked = selectedItemsArray.includes(item);
      onItemChange(item, isChecked);
    
      // Log the item being enabled
      if (isChecked) {
        console.log(`Enabling item: ${item.name}`);
      }
    });
  };    

  return (
    <div className="w-1/2 p-5">
      <h2 className="text-2xl text-left pb-3 uppercase font-bold text-foreground" style={{ fontFamily: 'Roboto' }}>Select Items</h2>
      {items.map((item, index) => (
        <div className="text-foreground" key={index}>
          <input
            type="checkbox"
            checked={selectedItems[item.name]}
            onChange={e => onItemChange(item, e.target.checked)}
          />
          <label className="pl-2">{item.name}</label>
        </div>
      ))}
      <div>
        <label className="text-xl text-foreground">Main: </label>
        <input type="number" value={maxMain} onChange={e => setMaxMain(Number(e.target.value))} min="0" max={totalMain} />
      </div>
      <div>
        <label className="text-xl text-foreground">Optional: </label>
        <input type="number" value={maxOptional} onChange={e => setMaxOptional(Number(e.target.value))} min="0" max={totalOptional} />
      </div>
      <div>
        <label className="text-xl text-foreground">Light: </label>
        <input type="number" value={maxLight} onChange={e => setMaxLight(Number(e.target.value))} min="0" max={totalLight} />
      </div>
      <button className="px-4 py-2 shadow-sm font-semibold text-sm text-white bg-border rounded-full" onClick={randomizeItems}>Randomize</button>
      <div>
      <input
            type="checkbox"
            checked={isLinkedItemsDisabled}
            onChange={e => {
              setIsLinkedItemsDisabled(e.target.checked);
              updateLinkedItemsBorder(e.target.checked);
            }}
          />
        <label className="pl-2">Disable linked items</label>
      </div>
    </div>
  );
};