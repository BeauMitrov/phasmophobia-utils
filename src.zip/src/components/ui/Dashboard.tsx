import React, { useState } from 'react';
import { itemData, Item } from '../../data/Items';
import { ItemContainer } from "./ItemContainer";
import { Information } from './Information';

export function Dashboard(): JSX.Element {
  const [selectedItems, setSelectedItems] = useState<Record<string, boolean>>(
    Object.fromEntries(itemData.map(item => [item.name, false]))
  );

  const [disabledItems, setDisabledItems] = useState<Record<string, boolean>>({});
  const [linkedItems, setLinkedItems] = useState<Record<string, boolean>>({});
  const [isLinkedItemsDisabled, setIsLinkedItemsDisabled] = useState(false);


  const handleCheckboxChange = (item: Item, isChecked: boolean) => {
    setSelectedItems(prevSelectedItems => {
      const newSelectedItems = { ...prevSelectedItems, [item.name]: isChecked };
  
      // Only process linked items if isLinkedItemsDisabled is false
      if (!isLinkedItemsDisabled) {
        const newLinkedItems = { ...linkedItems };
  
        itemData.forEach((otherItem: Item) => {
          // If the item has linked items and is selected
          if (otherItem.linked && newSelectedItems[otherItem.name]) {
            // Loop through all linked items
            otherItem.linked.forEach(linkedItemName => {
              // The linked item should still be selected
              newLinkedItems[linkedItemName] = true;
              newSelectedItems[linkedItemName] = true;
            });
          }
        });
  
        // Loop through all items again to unselect any unnecessary linked items
        itemData.forEach((otherItem: Item) => {
          // If the item is not selected but is a linked item
          if (!newSelectedItems[otherItem.name] && otherItem.linked) {
            otherItem.linked.forEach(linkedItemName => {
              // If no other selected items require this linked item
              if (!itemData.some(item => item.linked?.includes(linkedItemName) && newSelectedItems[item.name])) {
                newLinkedItems[linkedItemName] = false;
                newSelectedItems[linkedItemName] = false;
              }
            });
          }
        });
  
        setLinkedItems(newLinkedItems);
      }
  
      return newSelectedItems;
    });
  };

  const updateLinkedItemsBorder = (isDisabled: boolean) => {
    if (isDisabled) {
      setLinkedItems(prevLinkedItems => {
        const newLinkedItems = { ...prevLinkedItems };
        Object.keys(newLinkedItems).forEach(key => newLinkedItems[key] = false);
        return newLinkedItems;
      });
    } else {
      setLinkedItems(prevLinkedItems => {
        const newLinkedItems = { ...prevLinkedItems };
        itemData.forEach(item => {
          if (item.linked && selectedItems[item.name]) {
            item.linked.forEach(linkedItemName => newLinkedItems[linkedItemName] = true);
          }
        });
        return newLinkedItems;
      });
    }
  }
  

  const handleItemDisable = (item: Item, isDisabled: boolean) => {
    setDisabledItems((prevDisabledItems) => ({
      ...prevDisabledItems,
      [item.name]: isDisabled,
    }));
    if (isDisabled) {
      setSelectedItems((prevSelectedItems) => ({
        ...prevSelectedItems,
        [item.name]: false,
      }));
    }
  };
  
  const mainItems = itemData.filter(item => item.type === "main");
  const optionalItems = itemData.filter(item => item.type === "optional");
  const lightItems = itemData.filter(item => item.type === "light");  

  return (
    <div className="flex h-screen">
      <div className="w-1/2 flex flex-col">
        <div className="flex-grow">
          <ItemContainer title="Main Equipment" items={mainItems} selectedItems={selectedItems} disabledItems={disabledItems} linkedItems={linkedItems} onItemChange={handleCheckboxChange} onItemDisable={handleItemDisable}/>
        </div>
        <div className="flex-grow">
            <ItemContainer title="Optional Equipment" items={optionalItems} selectedItems={selectedItems} disabledItems={disabledItems} linkedItems={linkedItems} onItemChange={handleCheckboxChange} onItemDisable={handleItemDisable}/>
        </div>
        <div className="flex-grow">
            <ItemContainer title="Lights" items={lightItems} selectedItems={selectedItems} disabledItems={disabledItems} onItemChange={handleCheckboxChange} linkedItems={linkedItems} onItemDisable={handleItemDisable}/>
        </div>
      </div>
      <Information items={itemData} selectedItems={selectedItems} disabledItems={disabledItems} onItemChange={handleCheckboxChange} isLinkedItemsDisabled={isLinkedItemsDisabled} setIsLinkedItemsDisabled={setIsLinkedItemsDisabled} updateLinkedItemsBorder={updateLinkedItemsBorder}/>
    </div>
  );
}