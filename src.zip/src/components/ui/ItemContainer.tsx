import { Item } from "../../data/Items";

interface ItemContainerProps {
  title: string;
  items: Item[];
  selectedItems: Record<string, boolean>;
  disabledItems: Record<string, boolean>;
  linkedItems: Record<string, boolean>;
  onItemChange: (item: Item, isChecked: boolean) => void;
  onItemDisable: (item: Item, isDisabled: boolean) => void;
}

export function ItemContainer({ title, items, selectedItems, disabledItems, linkedItems, onItemChange, onItemDisable }: ItemContainerProps): JSX.Element {

  const handleRightClick = (item: Item, e: React.MouseEvent) => {
    e.preventDefault();
    onItemDisable(item, !disabledItems[item.name]);
  };

  return (
    <div className="flex justify-left pl-5 pt-4">
      <div>
        <h1 className="text-2xl text-left text-foreground uppercase font-bold" style={{ fontFamily: 'Roboto' }}>{title}</h1>
        {items.length === 0 ? (
          <div className="text-foreground text-3xl uppercase font-bold text-center mt-5 mb-5">No Items Selected</div>
        ) : (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-6 grid-rows-1 gap-2 pt-1 pl-0 pr-5">
            {items.map((item, index) => (
              <label
                key={index}
                className={`relative w-[144px] h-[144px] sm:w-[144px] sm:h-[144px] md:w-[144px] md:h-[144px] lg:w-[144px] lg:h-[144px] xl:w-[144px] xl:h-[144px] 2xl:w-[144px] 2xl:h-[144px] border-4 ${
                  disabledItems[item.name] ? 'border-disabled' : (
                    linkedItems[item.name] ? 'border-foreground' : (
                      selectedItems[item.name] ? 'border-enabled' : 'border-border'
                    )
                  )
                } overflow-hidden`}
                onContextMenu={(e) => handleRightClick(item, e)}
              >
                <input type="checkbox" className="hidden" checked={selectedItems[item.name]} onChange={(e) => onItemChange(item, e.target.checked)} disabled={disabledItems[item.name]} />
                <div className="absolute inset-0 z-10 bg-background bg-repeat"
                  style={{
                    backgroundImage: `linear-gradient(rgba(46, 53, 53, 0.5) 2px, transparent 1px),
                                      linear-gradient(90deg, rgba(46, 53, 53, 0.5) 2px, transparent 1px),
                                      linear-gradient(rgba(46, 53, 53, 0.28) 2px, transparent 1px),
                                      linear-gradient(90deg, rgba(46, 53, 53, 0.28) 2px, transparent 1px)`,
                    backgroundSize: '15px 15px',
                    backgroundPosition: '-0.5px -0.5px'
                  }}
                />
                <img src={item.image} alt={item.name} className="absolute z-20 object-cover w-full h-full" draggable="false" />
              </label>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
